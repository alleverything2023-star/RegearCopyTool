const categories = {
  weapon: {
    "Swords": [
      { name: "Broadsword", img: "images/weapon/Broadsword.PNG" },
      { name: "Claymore", img: "images/weapon/Claymore.PNG" },
      { name: "DualSwords", img: "images/weapon/DualSwords.PNG" },
      { name: "ClarentBlade", img: "images/weapon/ClarentBlade.PNG" },
      { name: "CarvingSword", img: "images/weapon/CarvingSword.PNG" },
      { name: "GalatinePair", img: "images/weapon/GalatinePair.PNG" },
      { name: "Kingmaker", img: "images/weapon/Kingmaker.PNG" },
      { name: "InfinityBlade", img: "images/weapon/InfinityBlade.PNG" }
    ],
    "Axes": [
      { name: "Battleaxe", img: "images/weapon/Battleaxe.PNG" },
      { name: "Greataxe", img: "images/weapon/Greataxe.PNG" },
      { name: "Halberd", img: "images/weapon/Halberd.PNG" },
      { name: "Carrioncaller", img: "images/weapon/Carrioncaller.PNG" },
      { name: "InfernalScythe", img: "images/weapon/InfernalScythe.PNG" },
      { name: "BearPaws", img: "images/weapon/BearPaws.PNG" },
      { name: "Realmbreaker", img: "images/weapon/Realmbreaker.PNG" },
      { name: "CrystalReaper", img: "images/weapon/CrystalReaper.PNG" }
    ],
    "Maces": [
      { name: "Mace", img: "images/weapon/Mace.PNG" },
      { name: "HeavyMace", img: "images/weapon/HeavyMace.PNG" },
      { name: "MorningStar", img: "images/weapon/MorningStar.PNG" },
      { name: "BedrockMace", img: "images/weapon/BedrockMace.PNG" },
      { name: "IncubusMace", img: "images/weapon/IncubusMace.PNG" },
      { name: "CamlannMace", img: "images/weapon/CamlannMace.PNG" },
      { name: "Oathkeepers", img: "images/weapon/Oathkeepers.PNG" },
      { name: "DreadstormMonarch", img: "images/weapon/DreadstormMonarch.PNG" }
    ],
    "Hammers": [
      { name: "Hammer", img: "images/weapon/Hammer.PNG" },
      { name: "Polehammer", img: "images/weapon/Polehammer.PNG" },
      { name: "GreatHammer", img: "images/weapon/GreatHammer.PNG" },
      { name: "Tombhammer", img: "images/weapon/Tombhammer.PNG" },
      { name: "ForgeHammers", img: "images/weapon/ForgeHammers.PNG" },
      { name: "Grovekeeper", img: "images/weapon/Grovekeeper.PNG" },
      { name: "HandofJustice", img: "images/weapon/HandofJustice.PNG" },
      { name: "TrueboltHammer", img: "images/weapon/TrueboltHammer.PNG" }
    ],
    "WarGloves": [
      { name: "BrawlerGloves", img: "images/weapon/BrawlerGloves.PNG" },
      { name: "BattleBracers", img: "images/weapon/BattleBracers.PNG" },
      { name: "SpikedGauntlets", img: "images/weapon/SpikedGauntlets.PNG" },
      { name: "UrsineMaulers", img: "images/weapon/UrsineMaulers.PNG" },
      { name: "HellfireHands", img: "images/weapon/HellfireHands.PNG" },
      { name: "RavenstrikeCestus", img: "images/weapon/RavenstrikeCestus.PNG" },
      { name: "FistsofAvalon", img: "images/weapon/FistsofAvalon.PNG" },
      { name: "ForcepulseBracers", img: "images/weapon/ForcepulseBracers.PNG" }
    ],
    "Crossbows": [
      { name: "Crossbow", img: "images/weapon/Crossbow.PNG" },
      { name: "LightCrossbow", img: "images/weapon/LightCrossbow.PNG" },
      { name: "HeavyCrossbow", img: "images/weapon/HeavyCrossbow.PNG" },
      { name: "WeepingRepeater", img: "images/weapon/WeepingRepeater.PNG" },
      { name: "Boltcasters", img: "images/weapon/Boltcasters.PNG" },
      { name: "Siegebow", img: "images/weapon/Siegebow.PNG" },
      { name: "EnergyShaper", img: "images/weapon/EnergyShaper.PNG" },
      { name: "ArclightBlasters", img: "images/weapon/ArclightBlasters.PNG" }
    ],
    "Bows": [
      { name: "Bow", img: "images/weapon/Bow.PNG" },
      { name: "Warbow", img: "images/weapon/Warbow.PNG" },
      { name: "Longbow", img: "images/weapon/Longbow.PNG" },
      { name: "WhisperingBow", img: "images/weapon/WhisperingBow.PNG" },
      { name: "WailingBow", img: "images/weapon/WailingBow.PNG" },
      { name: "BowofBadon", img: "images/weapon/BowofBadon.PNG" },
      { name: "Mistpiercer", img: "images/weapon/Mistpiercer.PNG" },
      { name: "SkystriderBow", img: "images/weapon/SkystriderBow.PNG" }
    ],
    "Daggers": [
      { name: "Dagger", img: "images/weapon/Dagger.PNG" },
      { name: "DaggerPair", img: "images/weapon/DaggerPair.PNG" },
      { name: "Claws", img: "images/weapon/Claws.PNG" },
      { name: "Bloodletter", img: "images/weapon/Bloodletter.PNG" },
      { name: "Demonfang", img: "images/weapon/Demonfang.PNG" },
      { name: "Deathgivers", img: "images/weapon/Deathgivers.PNG" },
      { name: "BridledFury", img: "images/weapon/BridledFury.PNG" },
      { name: "TwinSlayers", img: "images/weapon/TwinSlayers.PNG" }
    ],
    "Spears": [
      { name: "Spear", img: "images/weapon/Spear.PNG" },
      { name: "Pike", img: "images/weapon/Pike.PNG" },
      { name: "Glaive", img: "images/weapon/Glaive.PNG" },
      { name: "HeronSpear", img: "images/weapon/HeronSpear.PNG" },
      { name: "SpiritHunter", img: "images/weapon/SpiritHunter.PNG" },
      { name: "TrinitySpear", img: "images/weapon/TrinitySpear.PNG" },
      { name: "Daybreaker", img: "images/weapon/Daybreaker.PNG" },
      { name: "RiftGlaive", img: "images/weapon/RiftGlaive.PNG" }
    ],
    "Quarterstaves": [
      { name: "Quarterstaff", img: "images/weapon/Quarterstaff.PNG" },
      { name: "Iron-cladStaff", img: "images/weapon/Iron-cladStaff.PNG" },
      { name: "DoubleBladedStaff", img: "images/weapon/DoubleBladedStaff.PNG" },
      { name: "BlackMonkStave", img: "images/weapon/BlackMonkStave.PNG" },
      { name: "Soulscythe", img: "images/weapon/Soulscythe.PNG" },
      { name: "StaffofBalance", img: "images/weapon/StaffofBalance.PNG" },
      { name: "Grailseeker", img: "images/weapon/Grailseeker.PNG" },
      { name: "PhantomTwinblade", img: "images/weapon/PhantomTwinblade.PNG" }
    ],
    "ShapeshifterStaves": [
      { name: "ProwlingStaff", img: "images/weapon/ProwlingStaff.PNG" },
      { name: "RootboundStaff", img: "images/weapon/RootboundStaff.PNG" },
      { name: "PrimalStaff", img: "images/weapon/PrimalStaff.PNG" },
      { name: "BloodmoonStaff", img: "images/weapon/BloodmoonStaff.PNG" },
      { name: "HellspawnStaff", img: "images/weapon/HellspawnStaff.PNG" },
      { name: "EarthruneStaff", img: "images/weapon/EarthruneStaff.PNG" },
      { name: "Lightcaller", img: "images/weapon/Lightcaller.PNG" },
      { name: "StillgazeStaff", img: "images/weapon/StillgazeStaff.PNG" }
    ],
    "NatureStaves": [
      { name: "NatureStaff", img: "images/weapon/NatureStaff.PNG" },
      { name: "GreatNatureStaff", img: "images/weapon/GreatNatureStaff.PNG" },
      { name: "WildStaff", img: "images/weapon/WildStaff.PNG" },
      { name: "DruidicStaff", img: "images/weapon/DruidicStaff.PNG" },
      { name: "BlightStaff", img: "images/weapon/BlightStaff.PNG" },
      { name: "RampantStaff", img: "images/weapon/RampantStaff.PNG" },
      { name: "IronrootStaff", img: "images/weapon/IronrootStaff.PNG" },
      { name: "ForgebarkStaff", img: "images/weapon/ForgebarkStaff.PNG" }
    ],
    "FireStaves": [
      { name: "FireStaff", img: "images/weapon/FireStaff.PNG" },
      { name: "GreatFireStaff", img: "images/weapon/GreatFireStaff.PNG" },
      { name: "InfernalStaff", img: "images/weapon/InfernalStaff.PNG" },
      { name: "WildfireStaff", img: "images/weapon/WildfireStaff.PNG" },
      { name: "BrimstoneStaff", img: "images/weapon/BrimstoneStaff.PNG" },
      { name: "BlazingStaff", img: "images/weapon/BlazingStaff.PNG" },
      { name: "Dawnsong", img: "images/weapon/Dawnsong.PNG" },
      { name: "Flamewalker_Staff", img: "images/weapon/Flamewalker_Staff.PNG" }
    ],
    "HolyStaves": [
      { name: "HolyStaff", img: "images/weapon/HolyStaff.PNG" },
      { name: "GreatHolyStaff", img: "images/weapon/GreatHolyStaff.PNG" },
      { name: "DivineStaff", img: "images/weapon/DivineStaff.PNG" },
      { name: "LifetouchStaff", img: "images/weapon/LifetouchStaff.PNG" },
      { name: "FallenStaff", img: "images/weapon/FallenStaff.PNG" },
      { name: "RedemptionStaff", img: "images/weapon/RedemptionStaff.PNG" },
      { name: "Hallowfall", img: "images/weapon/Hallowfall.PNG" },
      { name: "ExaltedStaff", img: "images/weapon/ExaltedStaff.PNG" }
    ],
    "ArcaneStaves": [
      { name: "ArcaneStaff", img: "images/weapon/ArcaneStaff.PNG" },
      { name: "GreatArcaneStaff", img: "images/weapon/GreatArcaneStaff.PNG" },
      { name: "EnigmaticStaff", img: "images/weapon/EnigmaticStaff.PNG" },
      { name: "WitchworkStaff", img: "images/weapon/WitchworkStaff.PNG" },
      { name: "OccultStaff", img: "images/weapon/OccultStaff.PNG" },
      { name: "MalevolentLocus", img: "images/weapon/MalevolentLocus.PNG" },
      { name: "Evensong", img: "images/weapon/Evensong.PNG" },
      { name: "AstralStaff", img: "images/weapon/AstralStaff.PNG" }
    ],
    "FrostStaves": [
      { name: "FrostStaff", img: "images/weapon/FrostStaff.PNG" },
      { name: "GreatFrostStaff", img: "images/weapon/GreatFrostStaff.PNG" },
      { name: "GlacialStaff", img: "images/weapon/GlacialStaff.PNG" },
      { name: "HoarfrostStaff", img: "images/weapon/HoarfrostStaff.PNG" },
      { name: "IcicleStaff", img: "images/weapon/IcicleStaff.PNG" },
      { name: "PermafrostPrism", img: "images/weapon/PermafrostPrism.PNG" },
      { name: "Chillhowl", img: "images/weapon/Chillhowl.PNG" },
      { name: "ArcticStaff", img: "images/weapon/ArcticStaff.PNG" }
    ],
    "CursedStaves": [
      { name: "CursedStaff", img: "images/weapon/CursedStaff.PNG" },
      { name: "GreatCursedStaff", img: "images/weapon/GreatCursedStaff.PNG" },
      { name: "DemonicStaff", img: "images/weapon/DemonicStaff.PNG" },
      { name: "LifecurseStaff", img: "images/weapon/LifecurseStaff.PNG" },
      { name: "CursedSkull", img: "images/weapon/CursedSkull.PNG" },
      { name: "DamnationStaff", img: "images/weapon/DamnationStaff.PNG" },
      { name: "Shadowcaller", img: "images/weapon/Shadowcaller.PNG" },
      { name: "RotcallerStaff", img: "images/weapon/RotcallerStaff.PNG" }
    ]
  },

  offhand: {
    "Shields": [
      { name: "Shield", img: "images/offhand/Shield.PNG" },
      { name: "Sarcophagus", img: "images/offhand/Sarcophagus.PNG" },
      { name: "CaitiffShield", img: "images/offhand/CaitiffShield.PNG" },
      { name: "Facebreaker", img: "images/offhand/Facebreaker.PNG" },
      { name: "AstralAegis", img: "images/offhand/AstralAegis.PNG" },
      { name: "UnbreakableWand", img: "images/offhand/UnbreakableWand.PNG" }
    ],
    "Torches": [
      { name: "Torch", img: "images/offhand/Torch.PNG" },
      { name: "Mistcaller", img: "images/offhand/Mistcaller.PNG" },
      { name: "LeeringCane", img: "images/offhand/LeeringCane.PNG" },
      { name: "Cryptcandle", img: "images/offhand/Cryptcandle.PNG" },
      { name: "SacredScepter", img: "images/offhand/SacredScepter.PNG" },
      { name: "BlueflameTorch", img: "images/offhand/BlueflameTorch.PNG" }
    ],
    "Tomes": [
      { name: "TomeofSpells", img: "images/offhand/TomeofSpells.PNG" },
      { name: "EyeofSecrets", img: "images/offhand/EyeofSecrets.PNG" },
      { name: "Muisak", img: "images/offhand/Muisak.PNG" },
      { name: "Taproot", img: "images/offhand/Taproot.PNG" },
      { name: "CelestialCenser", img: "images/offhand/CelestialCenser.PNG" },
      { name: "TimelockedGrimoire", img: "images/offhand/TimelockedGrimoire.PNG" }
    ]
  },

  head: {
		"ClothHelmets": [
			{ name: "ScholarCowl", img: "images/head/ScholarCowl.PNG" },
			{ name: "ClericCowl", img: "images/head/ClericCowl.PNG" },
			{ name: "MageCowl", img: "images/head/MageCowl.PNG" },
			{ name: "RoyalCowl", img: "images/head/RoyalCowl.PNG" },
			{ name: "DruidCowl", img: "images/head/DruidCowl.PNG" },
			{ name: "FiendCowl", img: "images/head/FiendCowl.PNG" },
			{ name: "CultistCowl", img: "images/head/CultistCowl.PNG" },
			{ name: "FeyscaleHat", img: "images/head/FeyscaleHat.PNG" },
			{ name: "CowlofPurity", img: "images/head/CowlofPurity.PNG" }
		],
		"LetherHelmets": [
			{ name: "MercenaryHood", img: "images/head/MercenaryHood.PNG" },
			{ name: "HunterHood", img: "images/head/HunterHood.PNG" },
			{ name: "AssassinHood", img: "images/head/AssassinHood.PNG" },
			{ name: "RoyalHood", img: "images/head/RoyalHood.PNG" },
			{ name: "StalkerHood", img: "images/head/StalkerHood.PNG" },
			{ name: "HellionHood", img: "images/head/HellionHood.PNG" },
			{ name: "SpecterHood", img: "images/head/SpecterHood.PNG" },
			{ name: "MistwalkerHood", img: "images/head/MistwalkerHood.PNG" },
			{ name: "HoodofTenacity", img: "images/head/HoodofTenacity.PNG" }
		],
		"PlateHelmets": [
			{ name: "SoldierHelmet", img: "images/head/SoldierHelmet.PNG" },
			{ name: "KnightHelmet", img: "images/head/KnightHelmet.PNG" },
			{ name: "GuardianHelmet", img: "images/head/GuardianHelmet.PNG" },
			{ name: "RoyalHelmet", img: "images/head/RoyalHelmet.PNG" },
			{ name: "GraveguardHelmet", img: "images/head/GraveguardHelmet.PNG" },
			{ name: "DemonHelmet", img: "images/head/DemonHelmet.PNG" },
			{ name: "JudicatorHelmet", img: "images/head/JudicatorHelmet.PNG" },
			{ name: "DuskweaverHelmet", img: "images/head/DuskweaverHelmet.PNG" },
			{ name: "HelmetofValor", img: "images/head/HelmetofValor.PNG" }
		]
  },


  chest: {
		"ClothArmor": [
			{ name: "ScholarRobe", img: "images/chest/ScholarRobe.PNG" },
			{ name: "ClericRobe", img: "images/chest/ClericRobe.PNG" },
			{ name: "MageRobe", img: "images/chest/MageRobe.PNG" },
			{ name: "RoyalRobe", img: "images/chest/RoyalRobe.PNG" },
			{ name: "DruidRobe", img: "images/chest/DruidRobe.PNG" },
			{ name: "FiendRobe", img: "images/chest/FiendRobe.PNG" },
			{ name: "CultistRobe", img: "images/chest/CultistRobe.PNG" },
			{ name: "FeyscaleRobe", img: "images/chest/FeyscaleRobe.PNG" },
			{ name: "RobeofPurity", img: "images/chest/RobeofPurity.PNG" }
		],
		"LetherArmor": [
			{ name: "MercenaryJacket", img: "images/chest/MercenaryJacket.PNG" },
			{ name: "HunterJacket", img: "images/chest/HunterJacket.PNG" },
			{ name: "AssassinJacket", img: "images/chest/AssassinJacket.PNG" },
			{ name: "RoyalJacket", img: "images/chest/RoyalJacket.PNG" },
			{ name: "StalkerJacket", img: "images/chest/StalkerJacket.PNG" },
			{ name: "HellionJacket", img: "images/chest/HellionJacket.PNG" },
			{ name: "SpecterJacket", img: "images/chest/SpecterJacket.PNG" },
			{ name: "MistwalkerJacket", img: "images/chest/MistwalkerJacket.PNG" },
			{ name: "JacketofTenacity", img: "images/chest/JacketofTenacity.PNG" }
		],
		"PlateArmor": [
			{ name: "SoldierArmor", img: "images/chest/SoldierArmor.PNG" },
			{ name: "KnightArmor", img: "images/chest/KnightArmor.PNG" },
			{ name: "GuardianArmor", img: "images/chest/GuardianArmor.PNG" },
			{ name: "RoyalArmor", img: "images/chest/RoyalArmor.PNG" },
			{ name: "GraveguardArmor", img: "images/chest/GraveguardArmor.PNG" },
			{ name: "DemonArmor", img: "images/chest/DemonArmor.PNG" },
			{ name: "JudicatorArmor", img: "images/chest/JudicatorArmor.PNG" },
			{ name: "DuskweaverArmor", img: "images/chest/DuskweaverArmor.PNG" },
			{ name: "ArmorofValor", img: "images/chest/ArmorofValor.PNG" }
		]
},
  foot: {
		"ClothShoes": [
			{ name: "ScholarSandals", img: "images/foot/ScholarSandals.PNG" },
			{ name: "ClericSandals", img: "images/foot/ClericSandals.PNG" },
			{ name: "MageSandals", img: "images/foot/MageSandals.PNG" },
			{ name: "RoyalSandals", img: "images/foot/RoyalSandals.PNG" },
			{ name: "DruidSandals", img: "images/foot/DruidSandals.PNG" },
			{ name: "FiendSandals", img: "images/foot/FiendSandals.PNG" },
			{ name: "CultistSandals", img: "images/foot/CultistSandals.PNG" },
			{ name: "FeyscaleSandals", img: "images/foot/FeyscaleSandals.PNG" },
			{ name: "SandalsofPurity", img: "images/foot/SandalsofPurity.PNG" }
		],
		"LetherShoes": [
			{ name: "MercenaryShoes", img: "images/foot/MercenaryShoes.PNG" },
			{ name: "HunterShoes", img: "images/foot/HunterShoes.PNG" },
			{ name: "AssassinShoes", img: "images/foot/AssassinShoes.PNG" },
			{ name: "RoyalShoes", img: "images/foot/RoyalShoes.PNG" },
			{ name: "StalkerShoes", img: "images/foot/StalkerShoes.PNG" },
			{ name: "HellionShoes", img: "images/foot/HellionShoes.PNG" },
			{ name: "SpecterShoes", img: "images/foot/SpecterShoes.PNG" },
			{ name: "MistwalkerShoes", img: "images/foot/MistwalkerShoes.PNG" },
			{ name: "ShoesofTenacity", img: "images/foot/ShoesofTenacity.PNG" }
		],
		"PlateShoes": [
			{ name: "SoldierBoots", img: "images/foot/SoldierBoots.PNG" },
			{ name: "KnightBoots", img: "images/foot/KnightBoots.PNG" },
			{ name: "GuardianBoots", img: "images/foot/GuardianBoots.PNG" },
			{ name: "RoyalBoots", img: "images/foot/RoyalBoots.PNG" },
			{ name: "GraveguardBoots", img: "images/foot/GraveguardBoots.PNG" },
			{ name: "DemonBoots", img: "images/foot/DemonBoots.PNG" },
			{ name: "JudicatorBoots", img: "images/foot/JudicatorBoots.PNG" },
			{ name: "DuskweaverBoots", img: "images/foot/DuskweaverBoots.PNG" },
			{ name: "BootsofValor", img: "images/foot/BootsofValor.PNG" }
		]
},
  cape: [
    { name: "LymhurstCape", img: "images/cape/LymhurstCape.PNG" },
    { name: "FortSterlingCape", img: "images/cape/FortSterlingCape.PNG" },
    { name: "ThetfordCape", img: "images/cape/ThetfordCape.PNG" },
    { name: "MartlockCape", img: "images/cape/MartlockCape.PNG" },
    { name: "BridgewatchCape", img: "images/cape/BridgewatchCape.PNG" },
    { name: "BrecilienCape", img: "images/cape/BrecilienCape.PNG" },
    { name: "CaerleonCape", img: "images/cape/CaerleonCape.PNG" },
    { name: "SmugglerCape", img: "images/cape/SmugglerCape.PNG" },
    { name: "MorganaCape", img: "images/cape/MorganaCape.PNG" },
    { name: "UndeadCape", img: "images/cape/UndeadCape.PNG" },
    { name: "DemonCape", img: "images/cape/DemonCape.PNG" },
    { name: "HereticCape", img: "images/cape/HereticCape.PNG" },
    { name: "KeeperCape", img: "images/cape/KeeperCape.PNG" },
    { name: "AvalonianCape", img: "images/cape/AvalonianCape.PNG" }
  ]
};


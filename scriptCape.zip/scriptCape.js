const caLeftContainer = document.getElementById("cape-left");
const caImagesContainer = document.getElementById("cape-images");

let currentCaLeftItem = { name: "None", img: "images/n.PNG" };

function createCapeImages() {
  caImagesContainer.innerHTML = "";
  const items = categories.cape; 
  const totalCells = 14;

  for (let i = 0; i < totalCells; i++) {
    if (i < items.length) {
      const item = items[i];
      const img = document.createElement("img");
      img.src = item.img;
      img.alt = item.name;
      img.addEventListener("click", () => handleCapeSelection(item, img));
      caImagesContainer.appendChild(img);
    } else {
      const empty = document.createElement("div");
      empty.className = "empty-cell";
      caImagesContainer.appendChild(empty);
    }
  }
}

function handleCapeSelection(item, imgElement) {
  const imgs = caImagesContainer.querySelectorAll("img");
  imgs.forEach(img => img.classList.remove("selected"));

  if (currentCaLeftItem.name === item.name) {
    currentCaLeftItem = { name: "None", img: "images/n.PNG" };
  } else {
    currentCaLeftItem = item;
    imgElement.classList.add("selected");
  }

  updateCapeLeft(currentCaLeftItem);
}

function updateCapeLeft(item) {
  caLeftContainer.innerHTML = "";
  const div = document.createElement("div");
  div.className = "left-item";
  const img = document.createElement("img");
  img.src = item.img;
  img.alt = item.name;
  const name = document.createElement("span");
  name.textContent = item.name;
  div.appendChild(img);
  div.appendChild(name);
  caLeftContainer.appendChild(div);

  updateResult();
}

// 初期化
function initCape() {
  createCapeImages();
  updateCapeLeft(currentCaLeftItem);
}

window.addEventListener("DOMContentLoaded", initCape);

// Weapon 左右要素取得
const wLeftContainer = document.getElementById("w-left");
const wButtonsContainer = document.getElementById("w-buttons");
const wImagesContainer = document.getElementById("w-images");

// 現在の状態
let currentWCategory = "weapon";
let currentWSubCategory = null;
let currentWLeftItem = { name: "None", img: "images/n.PNG" };

// カテゴリボタン生成
function createWCategoryButtons(mainCategory) {
  wButtonsContainer.innerHTML = "";
  for (const subCategory in categories[mainCategory]) {
    const items = categories[mainCategory][subCategory];
    const button = document.createElement("button");
    button.className = "button-category";

    if (items.length > 0) {
      const img = document.createElement("img");
      img.src = items[0].img;
      img.alt = items[0].name;
      button.appendChild(img);
    }

    const span = document.createElement("span");
    span.textContent = subCategory;
    button.appendChild(span);

    button.addEventListener("click", () => {
      currentWSubCategory = subCategory;
      createWImages(mainCategory, subCategory);
      Array.from(wButtonsContainer.children).forEach(b => b.classList.remove("active"));
      button.classList.add("active");
    });

    wButtonsContainer.appendChild(button);
  }
}

// 画像グリッド生成
function createWImages(mainCategory, subCategory) {
  wImagesContainer.innerHTML = "";
  const items = categories[mainCategory][subCategory];
  const totalCells = 8;

  for (let i = 0; i < totalCells; i++) {
    if (i < items.length) {
      const item = items[i];
      const img = document.createElement("img");
      img.src = item.img;
      img.alt = item.name;
      img.addEventListener("click", () => handleWSelection(item, img));
      wImagesContainer.appendChild(img);
    } else {
      const empty = document.createElement("div");
      empty.className = "empty-cell";
      wImagesContainer.appendChild(empty);
    }
  }
}

// 選択処理
function handleWSelection(item, imgElement) {
  const imgs = wImagesContainer.querySelectorAll("img");
  imgs.forEach(img => img.classList.remove("selected"));

  if (currentWLeftItem.name === item.name) {
    currentWLeftItem = { name: "None", img: "images/n.PNG" };
  } else {
    currentWLeftItem = item;
    imgElement.classList.add("selected");
  }

  updateWLeft(currentWLeftItem);
}

// 左側更新
function updateWLeft(item) {
  wLeftContainer.innerHTML = "";
  const div = document.createElement("div");
  div.className = "left-item";
  const img = document.createElement("img");
  img.src = item.img;
  img.alt = item.name;
  const name = document.createElement("span");
  name.textContent = item.name;
  div.appendChild(img);
  div.appendChild(name);
  wLeftContainer.appendChild(div);

  updateResult();
}

// 初期化
function initWeapon() {
  createWCategoryButtons(currentWCategory);
  currentWSubCategory = Object.keys(categories.weapon)[0];
  createWImages(currentWCategory, currentWSubCategory);
  updateWLeft(currentWLeftItem);

  const firstButton = wButtonsContainer.querySelector("button");
  if (firstButton) firstButton.classList.add("active");
}

window.addEventListener("DOMContentLoaded", initWeapon);

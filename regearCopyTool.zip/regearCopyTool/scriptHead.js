const hLeftContainer = document.getElementById("h-left");
const hButtonsContainer = document.getElementById("h-buttons");
const hImagesContainer = document.getElementById("h-images");

let currentHCategory = "head";
let currentHSubCategory = null;
let currentHLeftItem = { name: "None", img: "images/n.PNG" };

function createHCategoryButtons(mainCategory) {
  hButtonsContainer.innerHTML = "";
  for (const subCategory in categories[mainCategory]) {
    const items = categories[mainCategory][subCategory];
    const button = document.createElement("button");
    button.className = "button-category";

    if (items.length > 0) {
      const img = document.createElement("img");
      img.src = items[0].img;
      img.alt = items[0].name;
      button.appendChild(img);
    }

    const span = document.createElement("span");
    span.textContent = subCategory;
    button.appendChild(span);

    button.addEventListener("click", () => {
      currentHSubCategory = subCategory;
      createHImages(mainCategory, subCategory);
      Array.from(hButtonsContainer.children).forEach(b => b.classList.remove("active"));
      button.classList.add("active");
    });

    hButtonsContainer.appendChild(button);
  }
}

function createHImages(mainCategory, subCategory) {
  hImagesContainer.innerHTML = "";
  const items = categories[mainCategory][subCategory];
  const totalCells = 10;

  for (let i = 0; i < totalCells; i++) {
    if (i < items.length) {
      const item = items[i];
      const img = document.createElement("img");
      img.src = item.img;
      img.alt = item.name;
      img.addEventListener("click", () => handleHSelection(item, img));
      hImagesContainer.appendChild(img);
    } else {
      const empty = document.createElement("div");
      empty.className = "empty-cell";
      hImagesContainer.appendChild(empty);
    }
  }
}

function handleHSelection(item, imgElement) {
  const imgs = hImagesContainer.querySelectorAll("img");
  imgs.forEach(img => img.classList.remove("selected"));

  if (currentHLeftItem.name === item.name) {
    currentHLeftItem = { name: "None", img: "images/n.PNG" };
  } else {
    currentHLeftItem = item;
    imgElement.classList.add("selected");
  }

  updateHLeft(currentHLeftItem);
}

function updateHLeft(item) {
  hLeftContainer.innerHTML = "";
  const div = document.createElement("div");
  div.className = "left-item";
  const img = document.createElement("img");
  img.src = item.img;
  img.alt = item.name;
  const name = document.createElement("span");
  name.textContent = item.name;
  div.appendChild(img);
  div.appendChild(name);
  hLeftContainer.appendChild(div);

  updateResult();
}

function initHead() {
  createHCategoryButtons(currentHCategory);
  currentHSubCategory = Object.keys(categories.head)[0];
  createHImages(currentHCategory, currentHSubCategory);
  updateHLeft(currentHLeftItem);

  const firstButton = hButtonsContainer.querySelector("button");
  if (firstButton) firstButton.classList.add("active");
}

window.addEventListener("DOMContentLoaded", initHead);

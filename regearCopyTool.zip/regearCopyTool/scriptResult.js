function updateResult() {
  const resultCopy = document.getElementById("result-copy");
  const lines = [
    "regear",
    "weapon:" + (currentWLeftItem.name !== "None" ? currentWLeftItem.name : ""),
    "offhand:" + (currentOLeftItem.name !== "None" ? currentOLeftItem.name : ""),
    "head:" + (currentHLeftItem.name !== "None" ? currentHLeftItem.name : ""),
    "chest:" + (currentCLeftItem.name !== "None" ? currentCLeftItem.name : ""),
    "foot:" + (currentFLeftItem.name !== "None" ? currentFLeftItem.name : ""),
    "cape:" + (currentCaLeftItem.name !== "None" ? currentCaLeftItem.name : "")
  ];
  resultCopy.value = lines.join("\n");
}

function copyButton(id) {
  const textarea = document.getElementById(id);
  textarea.select();
  document.execCommand("copy");
  document.getElementById('pcopy').textContent = "コピーしました";
}

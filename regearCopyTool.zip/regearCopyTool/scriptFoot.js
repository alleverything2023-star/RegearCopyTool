const fLeftContainer = document.getElementById("f-left");
const fButtonsContainer = document.getElementById("f-buttons");
const fImagesContainer = document.getElementById("f-images");

let currentFCategory = "foot";
let currentFSubCategory = null;
let currentFLeftItem = { name: "None", img: "images/n.PNG" };

function createFCategoryButtons(mainCategory) {
  fButtonsContainer.innerHTML = "";
  for (const subCategory in categories[mainCategory]) {
    const items = categories[mainCategory][subCategory];
    const button = document.createElement("button");
    button.className = "button-category";

    if (items.length > 0) {
      const img = document.createElement("img");
      img.src = items[0].img;
      img.alt = items[0].name;
      button.appendChild(img);
    }

    const span = document.createElement("span");
    span.textContent = subCategory;
    button.appendChild(span);

    button.addEventListener("click", () => {
      currentFSubCategory = subCategory;
      createFImages(mainCategory, subCategory);
      Array.from(fButtonsContainer.children).forEach(b => b.classList.remove("active"));
      button.classList.add("active");
    });

    fButtonsContainer.appendChild(button);
  }
}

function createFImages(mainCategory, subCategory) {
  fImagesContainer.innerHTML = "";
  const items = categories[mainCategory][subCategory];
  const totalCells = 10;

  for (let i = 0; i < totalCells; i++) {
    if (i < items.length) {
      const item = items[i];
      const img = document.createElement("img");
      img.src = item.img;
      img.alt = item.name;
      img.addEventListener("click", () => handleFSelection(item, img));
      fImagesContainer.appendChild(img);
    } else {
      const empty = document.createElement("div");
      empty.className = "empty-cell";
      fImagesContainer.appendChild(empty);
    }
  }
}

function handleFSelection(item, imgElement) {
  const imgs = fImagesContainer.querySelectorAll("img");
  imgs.forEach(img => img.classList.remove("selected"));

  if (currentFLeftItem.name === item.name) {
    currentFLeftItem = { name: "None", img: "images/n.PNG" };
  } else {
    currentFLeftItem = item;
    imgElement.classList.add("selected");
  }

  updateFLeft(currentFLeftItem);
}

function updateFLeft(item) {
  fLeftContainer.innerHTML = "";
  const div = document.createElement("div");
  div.className = "left-item";
  const img = document.createElement("img");
  img.src = item.img;
  img.alt = item.name;
  const name = document.createElement("span");
  name.textContent = item.name;
  div.appendChild(img);
  div.appendChild(name);
  fLeftContainer.appendChild(div);

  updateResult();
}

function initFoot() {
  createFCategoryButtons(currentFCategory);
  currentFSubCategory = Object.keys(categories.foot)[0];
  createFImages(currentFCategory, currentFSubCategory);
  updateFLeft(currentFLeftItem);

  const firstButton = fButtonsContainer.querySelector("button");
  if (firstButton) firstButton.classList.add("active");
}

window.addEventListener("DOMContentLoaded", initFoot);

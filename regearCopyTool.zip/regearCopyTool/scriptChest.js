const cLeftContainer = document.getElementById("c-left");
const cButtonsContainer = document.getElementById("c-buttons");
const cImagesContainer = document.getElementById("c-images");

let currentCCategory = "chest";
let currentCSubCategory = null;
let currentCLeftItem = { name: "None", img: "images/n.PNG" };

function createCCategoryButtons(mainCategory) {
  cButtonsContainer.innerHTML = "";
  for (const subCategory in categories[mainCategory]) {
    const items = categories[mainCategory][subCategory];
    const button = document.createElement("button");
    button.className = "button-category";

    if (items.length > 0) {
      const img = document.createElement("img");
      img.src = items[0].img;
      img.alt = items[0].name;
      button.appendChild(img);
    }

    const span = document.createElement("span");
    span.textContent = subCategory;
    button.appendChild(span);

    button.addEventListener("click", () => {
      currentCSubCategory = subCategory;
      createCImages(mainCategory, subCategory);
      Array.from(cButtonsContainer.children).forEach(b => b.classList.remove("active"));
      button.classList.add("active");
    });

    cButtonsContainer.appendChild(button);
  }
}

function createCImages(mainCategory, subCategory) {
  cImagesContainer.innerHTML = "";
  const items = categories[mainCategory][subCategory];
  const totalCells = 10;

  for (let i = 0; i < totalCells; i++) {
    if (i < items.length) {
      const item = items[i];
      const img = document.createElement("img");
      img.src = item.img;
      img.alt = item.name;
      img.addEventListener("click", () => handleCSelection(item, img));
      cImagesContainer.appendChild(img);
    } else {
      const empty = document.createElement("div");
      empty.className = "empty-cell";
      cImagesContainer.appendChild(empty);
    }
  }
}

function handleCSelection(item, imgElement) {
  const imgs = cImagesContainer.querySelectorAll("img");
  imgs.forEach(img => img.classList.remove("selected"));

  if (currentCLeftItem.name === item.name) {
    currentCLeftItem = { name: "None", img: "images/n.PNG" };
  } else {
    currentCLeftItem = item;
    imgElement.classList.add("selected");
  }

  updateCLeft(currentCLeftItem);
}

function updateCLeft(item) {
  cLeftContainer.innerHTML = "";
  const div = document.createElement("div");
  div.className = "left-item";
  const img = document.createElement("img");
  img.src = item.img;
  img.alt = item.name;
  const name = document.createElement("span");
  name.textContent = item.name;
  div.appendChild(img);
  div.appendChild(name);
  cLeftContainer.appendChild(div);

  updateResult();
}

function initChest() {
  createCCategoryButtons(currentCCategory);
  currentCSubCategory = Object.keys(categories.chest)[0];
  createCImages(currentCCategory, currentCSubCategory);
  updateCLeft(currentCLeftItem);

  const firstButton = cButtonsContainer.querySelector("button");
  if (firstButton) firstButton.classList.add("active");
}

window.addEventListener("DOMContentLoaded", initChest);

const oLeftContainer = document.getElementById("o-left");
const oButtonsContainer = document.getElementById("o-buttons");
const oImagesContainer = document.getElementById("o-images");

let currentOCategory = "offhand";
let currentOSubCategory = null;
let currentOLeftItem = { name: "None", img: "images/n.PNG" };

function createOCategoryButtons(mainCategory) {
  oButtonsContainer.innerHTML = "";
  for (const subCategory in categories[mainCategory]) {
    const items = categories[mainCategory][subCategory];
    const button = document.createElement("button");
    button.className = "button-category";

    if (items.length > 0) {
      const img = document.createElement("img");
      img.src = items[0].img;
      img.alt = items[0].name;
      button.appendChild(img);
    }

    const span = document.createElement("span");
    span.textContent = subCategory;
    button.appendChild(span);

    button.addEventListener("click", () => {
      currentOSubCategory = subCategory;
      createOImages(mainCategory, subCategory);
      Array.from(oButtonsContainer.children).forEach(b => b.classList.remove("active"));
      button.classList.add("active");
    });

    oButtonsContainer.appendChild(button);
  }
}

function createOImages(mainCategory, subCategory) {
  oImagesContainer.innerHTML = "";
  const items = categories[mainCategory][subCategory];
  const totalCells = 6;

  for (let i = 0; i < totalCells; i++) {
    if (i < items.length) {
      const item = items[i];
      const img = document.createElement("img");
      img.src = item.img;
      img.alt = item.name;
      img.addEventListener("click", () => handleOSelection(item, img));
      oImagesContainer.appendChild(img);
    } else {
      const empty = document.createElement("div");
      empty.className = "empty-cell";
      oImagesContainer.appendChild(empty);
    }
  }
}

function handleOSelection(item, imgElement) {
  const imgs = oImagesContainer.querySelectorAll("img");
  imgs.forEach(img => img.classList.remove("selected"));

  if (currentOLeftItem.name === item.name) {
    currentOLeftItem = { name: "None", img: "images/n.PNG" };
  } else {
    currentOLeftItem = item;
    imgElement.classList.add("selected");
  }

  updateOLeft(currentOLeftItem);
}

function updateOLeft(item) {
  oLeftContainer.innerHTML = "";
  const div = document.createElement("div");
  div.className = "left-item";
  const img = document.createElement("img");
  img.src = item.img;
  img.alt = item.name;
  const name = document.createElement("span");
  name.textContent = item.name;
  div.appendChild(img);
  div.appendChild(name);
  oLeftContainer.appendChild(div);

  updateResult();
}

function initOffhand() {
  createOCategoryButtons(currentOCategory);
  currentOSubCategory = Object.keys(categories.offhand)[0];
  createOImages(currentOCategory, currentOSubCategory);
  updateOLeft(currentOLeftItem);

  const firstButton = oButtonsContainer.querySelector("button");
  if (firstButton) firstButton.classList.add("active");
}

window.addEventListener("DOMContentLoaded", initOffhand);
